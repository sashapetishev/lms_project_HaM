import random
from characters.assasin import Assasin
from characters.axe import Axe
from characters.invoker import Invoker
from enemy.enemy import Enemy,Enemy2,Enemy3
import story.text_storyteller as text_storyteller
from story import story_choice


player = None
enemy = None
difficult = 1

def choice_character():
    global player
    global enemy

    enemy = Enemy()
    player_name = input("Введите имя будущего персонажа: ")
    player_class_character = input(
        """
Выберите класс будещего
персонажа(Ассасин, Акс, Инвокер): """
    )

    if player_class_character.lower() == "акс":
        player = Axe(player_name)
        storyteller()

    elif player_class_character.lower() == "ассасин":
        player = Assasin(player_name)
        storyteller()

    elif player_class_character.lower() == "инвокер":
        player = Invoker(player_name)
        storyteller()

    else:
        print("Неверно выбран класс персонажа. Попробуй ещё раз")
        choice_character()

def enemy_procast():
    enemy.use_heal_thing()
    player.getting_damage(enemy)
    print(f"Противник нанес вам {enemy.damage}")

def battle():
    print("""
          
Вы направляетесь в стены королевства на воротах вам преграждает путь стражник в латах, против него целесообразнее будет использовать магию.
          
          """)
    enemy = Enemy()
    flag = True
    cooldown = 0
    while flag:
        if player.__class__.__name__ == "Axe":
            print(
                """
Тебе доступны следующие способности:
1. Усиление брони, твоя броня усилится в 1,5 раза.
2. Нанести урон врагу.
                    """
            )
            choice_ability_paladin = int(input("Введите ваш выбор: "))
            if choice_ability_paladin == 1:
                if cooldown % 2==0:
                    player.double_armor()
                    enemy_procast()
                    cooldown+=1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")
                else:
                    print("""
Способность на перезарядке.                         
                          """)
                    

            elif choice_ability_paladin == 2:
                if cooldown == 1:
                    cooldown -= 1        
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")
                else:
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")

        elif player.__class__.__name__ == "Assasin":
            print(
                """
Тебе доступны следующие способности:
1. Двойной урон, твой урон увеличится в 2 раза
2. Нанести урон врагу.
Врожденная способность: Шанс уклонения 20% """
            )
            choice_ability_assasin = int(input("Введите ваш выбор: "))
            if choice_ability_assasin == 1:
                if cooldown % 2==0:
                    player.double_damage()
                    player.passive_ability()
                    enemy_procast()
                    cooldown+=1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")
                else:
                    print("""
Способность на перезарядке.                         
                          """)

            elif choice_ability_assasin == 2:
                if cooldown == 1:
                    cooldown -= 1        
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")
                else:
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")

        elif player.__class__.__name__ == "Invoker":
            print(
                """
Тебе доступны следующие способности:
1. Санстрайк. Враг получит чистый урон,
который не будет уменьшен из-за брони.
Он равен обычному урону
2. Отражение урона. Урон от атаки врага
получит враг, который вас атаковал.
3. Нанести урон врагу. """
            )
            choice_ability_invoker = int(input("Введите ваш выбор: "))

            if choice_ability_invoker == 1:
                if cooldown % 2==0:
                    player.mages_attack()
                    enemy_procast()
                    cooldown+=1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    print("""
Способность на перезарядке.                         
                          """)

            elif choice_ability_invoker == 2:
                if cooldown % 2==0:
                    player.mirror_damage()
                    cooldown+=1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    print("""
Способность на перезарядке.                         
                          """)

            elif choice_ability_invoker == 3:
                if cooldown == 1:
                    cooldown -= 1        
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")

            else:
                print("Такой способности не существует!")
        elif enemy.health <= 0:
            flag = False
            if player.__class__.__name__ == "Axe":
                text_storyteller.past_story(46,46)
            elif player.__class__.__name__ == "Assasin":
                text_storyteller.past_story(48,48)
            elif player.__class__.__name__ == "Invoker":
                text_storyteller.past_story(44,44)
            story_choice()
        elif player.health <= 0:
            flag = False
            restart = input("Введите R чтобы возродиться").lower()
            if restart == "r":
                battle()
            else:
                print("Некорректный ввод")
            
def battle2():
    print("""
          
Вы пришли в замок за артефактом, но встречаете Рыцарей света в большом количестве, пока основные силы сражаются друг с другом вы решаете напасть на их командующего.          
          
          """)
    enemy = Enemy2()
    flag = True
    cooldown = 0
    while flag:
        if player.__class__.__name__ == "Axe":
            print(
                """
Тебе доступны следующие способности:
1. Усиление брони, твоя броня усилится в 1,5 раза.
2. Нанести урон врагу.
                    """
            )
            choice_ability_paladin = int(input("Введите ваш выбор: "))
            if choice_ability_paladin == 1:
                if cooldown % 2==0:
                    player.double_armor()
                    enemy_procast()
                    cooldown+=1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")
                else:
                    print("""
Способность на перезарядке.                         
                          """)
                    

            elif choice_ability_paladin == 2:
                if cooldown == 1:
                    cooldown -= 1        
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")
                else:
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")

        elif player.__class__.__name__ == "Assasin":
            print(
                """
Тебе доступны следующие способности:
1. Двойной урон, твой урон увеличится в 2 раза
2. Нанести урон врагу.
Врожденная способность: Шанс уклонения 20% """
            )
            choice_ability_assasin = int(input("Введите ваш выбор: "))
            if choice_ability_assasin == 1:
                if cooldown % 2==0:
                    player.double_damage()
                    player.passive_ability()
                    enemy_procast()
                    cooldown+=1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")
                else:
                    print("""
Способность на перезарядке.                         
                          """)

            elif choice_ability_assasin == 2:
                if cooldown == 1:
                    cooldown -= 1        
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")
                else:
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")

        elif player.__class__.__name__ == "Invoker":
            print(
                """
Тебе доступны следующие способности:
1. Санстрайк. Враг получит чистый урон,
который не будет уменьшен из-за брони.
Он равен обычному урону
2. Отражение урона. Урон от атаки врага
получит враг, который вас атаковал.
3. Нанести урон врагу. """
            )
            choice_ability_invoker = int(input("Введите ваш выбор: "))

            if choice_ability_invoker == 1:
                if cooldown % 2==0:
                    player.mages_attack()
                    enemy_procast()
                    cooldown+=1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    print("""
Способность на перезарядке.                         
                          """)

            elif choice_ability_invoker == 2:
                if cooldown % 2==0:
                    player.mirror_damage()
                    cooldown+=1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    print("""
Способность на перезарядке.                         
                          """)

            elif choice_ability_invoker == 3:
                if cooldown == 1:
                    cooldown -= 1        
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")

            else:
                print("Такой способности не существует!")
        elif enemy.health <= 0:
            flag = False
            text_storyteller.past_story(62,64) 
        elif player.health <= 0:
            flag = False
            text_storyteller.past_story(66,69)                


def battle3():
    print("""
          
Вы вместе с рыцарями пришли в замок за артефактом, вам преграждают путь войска Теневых братьев, вы решаете сразиться с превосходящим вас по силе паладином теней.
          
          """)
    enemy = Enemy3()
    flag = True
    cooldown = 0
    while flag:
        if player.__class__.__name__ == "Axe":
            print(
                """
Тебе доступны следующие способности:
1. Усиление брони, твоя броня усилится в 1,5 раза.
2. Нанести урон врагу.
                    """
            )
            choice_ability_paladin = int(input("Введите ваш выбор: "))
            if choice_ability_paladin == 1:
                if cooldown % 2==0:
                    player.double_armor()
                    enemy_procast()
                    cooldown+=1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")
                else:
                    print("""
Способность на перезарядке.                         
                          """)
                    

            elif choice_ability_paladin == 2:
                if cooldown == 1:
                    cooldown -= 1        
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")
                else:
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")

        elif player.__class__.__name__ == "Assasin":
            print(
                """
Тебе доступны следующие способности:
1. Двойной урон, твой урон увеличится в 2 раза
2. Нанести урон врагу.
Врожденная способность: Шанс уклонения 20% """
            )
            choice_ability_assasin = int(input("Введите ваш выбор: "))
            if choice_ability_assasin == 1:
                if cooldown % 2==0:
                    player.double_damage()
                    player.passive_ability()
                    enemy_procast()
                    cooldown+=1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")
                else:
                    print("""
Способность на перезарядке.                         
                          """)

            elif choice_ability_assasin == 2:
                if cooldown == 1:
                    cooldown -= 1        
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")
                else:
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")

        elif player.__class__.__name__ == "Invoker":
            print(
                """
Тебе доступны следующие способности:
1. Санстрайк. Враг получит чистый урон,
который не будет уменьшен из-за брони.
Он равен обычному урону
2. Отражение урона. Урон от атаки врага
получит враг, который вас атаковал.
3. Нанести урон врагу. """
            )
            choice_ability_invoker = int(input("Введите ваш выбор: "))

            if choice_ability_invoker == 1:
                if cooldown % 2==0:
                    player.mages_attack()
                    enemy_procast()
                    cooldown+=1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    print("""
Способность на перезарядке.                         
                          """)

            elif choice_ability_invoker == 2:
                if cooldown % 2==0:
                    player.mirror_damage()
                    cooldown+=1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    print("""
Способность на перезарядке.                         
                          """)

            elif choice_ability_invoker == 3:
                if cooldown == 1:
                    cooldown -= 1        
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")

            else:
                print("Такой способности не существует!")
        elif enemy.health <= 0:
            flag = False
            text_storyteller.past_story(71,74)
        elif player.health <= 0:
            flag = False
            text_storyteller.past_story(76,78)

def storyteller():
    print(
        """
Привет! Ты попал в увлекательное путешествие.
Тебе предстоит сразиться со врагами и выбрать путь,
по которому ты будешь идти
        """
    )
    
    choice = int(
        input(
            """
Введи сюда своё решение: 
1. Я согласен. Пойду дальше
2. Нет, спасибо, я лучше откажусь
                        
    Выбери 1 или 2:
    """
        )
    )
    if choice == 1:
        print("История твоего персонажа была такой.")
        if player.__class__.__name__ == "Axe":
            text_storyteller.past_story(2, 11)
        elif player.__class__.__name__ == "Invoker":
            text_storyteller.past_story(23, 34)
        elif player.__class__.__name__ == "Assasin":
            text_storyteller.past_story(13, 21)
        else:
            choice_character()
        choice = int(
            input(
                """
Начать приключение?

1.Да
2.Я хочу поменять персонажа.
              
Выбери 1 или 2:
"""
            )
        )
        if choice == 1:
            text_storyteller.past_story(38, 42)
            battle()
        elif choice == 2:
            choice_character()

    elif choice == 2:
        choice_exit = input("Вы уверены что хотите выйти?(Да / Нет):")

        if choice_exit.lower() == "да":
            print("Спасибо, что зашел. Удачи!")
            flag = False

        elif choice_exit.lower() == "нет":
            battle()

        else:
            print("Некорректный ввод")

def lobby():
    global difficult

    choice = int(
        input(
            """
Heroes and Magic
          
1.Начать игру
2.Уровень сложности

Выбери 1 или 2:
"""
        )
    )
    if choice == 1:
        return choice_character()

    elif choice == 2:
        choice2 = int(
            input(
                """
1.Низкий
2.Нормальный
3.Хардкор

Выбери 1 или 2 или 3:"""
            )
        )
        if choice2 == 1:
            difficult = 0.5
            return lobby()
        elif choice2 == 2:
            difficult = 1
            return lobby()
        elif choice2 == 3:
            difficult = 1.5
            return lobby()
        else:
            print("Некорректный ввод")
            return lobby()
    else:
        print("Некорректный ввод")
        return lobby()