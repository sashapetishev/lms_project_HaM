from game import lobby

if __name__ == "__main__":
    lobby()