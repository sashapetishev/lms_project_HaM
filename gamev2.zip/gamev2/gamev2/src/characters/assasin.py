import random
from .character import Character

class Assasin(Character):
    def __init__(self, name="default", health_pull=90, damage=20, dodge_attack=20):
        super().__init__(name, health_pull, damage, dodge_attack)
        self.dodge_attack = dodge_attack

    def passive_ability(self, enemy):
        if random.randrange(0, 100) <= self.dodge_attack:
            self.health += enemy.damage
            self.dodge_attack *= 1.05
            if self.health > 100:
                self.health = self.health_pull
        else:
            self.health -= enemy.damage

    def double_damage(self):
        print(
            """
Вы используете способность "Двойной урон".
Ваш урон увеличен в 2 раза.
Перезарядка займет один ход
        """
        )
        self.damage *= 2