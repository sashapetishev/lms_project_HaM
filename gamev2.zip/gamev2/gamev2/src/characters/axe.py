from .character import Character

class Axe(Character):
    def __init__(self, name="default", health_pull=120, damage=17, mana=80, armor=10):
        super().__init__(name, health_pull, damage, mana, armor)

    def double_armor(self):
        self.armor *= 1.5
        print(
            f"""
Вы использовали способность "Усиление брони"
Ваше количество брони: {self.armor}
        """
        )