from game import difficult
from game import player


class Enemy:
    def __init__(
        self, health_pull=100 * difficult, damage=17 * difficult, armor=3 * difficult
    ):
        self.armor = armor
        self.damage = damage
        self.health_pull = health_pull
        self.health = health_pull

    def getting_damage(self, player):
        self.health -= player.damage - 1 - self.armor / 100

    def use_heal_thing(self):
        self.health += 5
        if self.health > 100:
            self.health = self.health_pull


class Enemy2(Enemy):
    def __init__(
        self, health_pull=90 * difficult, damage=19 * difficult, armor=5 * difficult
    ):
        super().__init__(health_pull, damage, armor)


class Enemy3(Enemy):
    def __init__(
        self, health_pull=100 * difficult, damage=20 * difficult, armor=8 * difficult
    ):
        super().__init__(health_pull, damage, armor)
