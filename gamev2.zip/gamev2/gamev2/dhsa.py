import random
from random import randrange
import story.text_storyteller as text_storyteller



player = None
enemy = None
difficult = 1


class Character:
    def __init__(self, name, health_pull=100, damage=15, armor=5):
        self.name = name
        self.health_pull = health_pull
        self.health = health_pull
        self.damage = damage
        self.armor = armor

    def getting_damage(self):
        self.health-=enemy.damage-1-self.armor/100

    def use_heal_thing(self):
        self.health += 20
        print(
            f"""
Вы восстановили здоровье.
Ваш уровень здоровья: {self.health}
"""
        )


class Assasin(Character):
    def __init__(
        self,
        name="default",
        health_pull=90 // difficult,
        damage=20 // difficult,
        dodge_attack=20 // difficult,
    ):
        super().__init__(name, health_pull, damage, dodge_attack)
        self.dodge_attack = dodge_attack

    def passive_ability(self):
        if random.randrange(0, 100) <= self.dodge_attack:
            self.health += Enemy.damage
            self.dodge_attack *= 1.05
            if self.health > 100:
                self.healh = self.health_pull
        else:
            self.health -= enemy.damage

    def double_damage(self):
        print(
            """
Вы используете способность "Двойной урон".
Ваш урон увеличен в 2 раза.
Перезарядка займет один ход
        """
        )
        self.damage *= 2


class Axe(Character):
    def __init__(
        self,
        name="default",
        health_pull=120 // difficult,
        damage=17 // difficult,
        armor=10 // difficult,
    ):
        super().__init__(name, health_pull, damage, armor)

    def double_armor(self):
        self.armor *= 1.5
        print(
            f"""
Вы использовали способность "Усиление брони"
Ваше количество брони: {self.armor}
        """
        )


class Invoker(Character):
    def __init__(
        self,
        name="default",
        health_pull=80 // difficult,
        damage=14 // difficult,
        armor=4 // difficult,
    ):
        super().__init__(name, health_pull, damage, armor)

    def mages_attack(self):
        mages_attack = self.damage+20
        print(
            """
        Вы использовали способность "Санстрайк"
        """
        )
        enemy.health -= mages_attack

    def mirror_damage(self):
        enemy.health -= enemy.damage
        print(
            """
Вы использовали способность "Отражение урона"
Вы отразите одну атаку, урон получит враг, который атаковал вас.
        """
        )


class Enemy:
    def __init__(
        self, health_pull=100 * difficult, damage=17 * difficult, armor=3 * difficult
    ):
        self.armor = armor
        self.damage = damage
        self.health_pull = health_pull
        self.health = health_pull

    def getting_damage(self):
        self.health-=player.damage-1-self.armor/100

    def use_heal_thing(self):
        self.health += 5
        if self.health > 100:
            self.health = self.health_pull


def choice_character():
    global player
    global enemy

    enemy = Enemy()
    player_name = input("Введите имя будущего персонажа: ")
    player_class_character = input(
        """
Выберите класс будещего
персонажа(Ассасин, Акс, Инвокер): """
    )

    if player_class_character.lower() == "акс":
        player = Axe(player_name)
        storyteller()

    elif player_class_character.lower() == "ассасин":
        player = Assasin(player_name)
        storyteller()

    elif player_class_character.lower() == "инвокер":
        player = Invoker(player_name)
        storyteller()

    else:
        print("Неверно выбран класс персонажа. Попробуй ещё раз")
        choice_character()


def enemy_procast():
    enemy.use_heal_thing()
    player.getting_damage()
    print(f"Противник нанес вам {enemy.damage}")


def battle():
    flag = True
    cooldown = 0
    while flag:
        if player.health <= 0:
            flag = False
            print("Вы проиграли, можете перезапустить игру, нажав " R"")
        elif enemy.health <= 0:
            flag = False
            print(
                """
Вы победили, можете идти дальше.
Враг получил дополнительный бонус к здоровью.
                  """
            )

        if player.__class__.__name__ == "Axe":
            print(
                """
Тебе доступны следующие способности:
1. Усиление брони, твоя броня усилится в 1,5 раза.
2. Нанести урон врагу.
                    """
            )
            choice_ability_paladin = int(input("Введите ваш выбор: "))
            if choice_ability_paladin == 1:
                if cooldown % 2==0:
                    player.double_armor()
                    enemy_procast()
                    cooldown+=1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    print("""
Способность на перезарядке.                         
                          """)
                    

            elif choice_ability_paladin == 2:
                if cooldown == 1:
                    cooldown -= 1        
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")

        elif player.__class__.__name__ == "Assasin":
            print(
                """
Тебе доступны следующие способности:
1. Двойной урон, твой урон увеличится в 2 раза
2. Нанести урон врагу.
Врожденная способность: Шанс уклонения 20% """
            )
            choice_ability_assasin = int(input("Введите ваш выбор: "))
            if choice_ability_assasin == 1:
                if cooldown % 2==0:
                    player.double_damage()
                    player.passive_ability()
                    enemy_procast()
                    cooldown+=1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    print("""
Способность на перезарядке.                         
                          """)

            elif choice_ability_assasin == 2:
                if cooldown == 1:
                    cooldown -= 1        
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")

        elif player.__class__.__name__ == "Invoker":
            print(
                """
Тебе доступны следующие способности:
1. Санстрайк. Враг получит чистый урон,
который не будет уменьшен из-за брони.
Он равен обычному урону
2. Отражение урона. Урон от атаки врага
получит враг, который вас атаковал.
3. Нанести урон врагу. """
            )
            choice_ability_invoker = int(input("Введите ваш выбор: "))

            if choice_ability_invoker == 1:
                if cooldown % 2==0:
                    player.mages_attack()
                    enemy_procast()
                    cooldown+=1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    print("""
Способность на перезарядке.                         
                          """)

            elif choice_ability_invoker == 2:
                if cooldown % 2==0:
                    player.mirror_damage()
                    cooldown+=1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    print("""
Способность на перезарядке.                         
                          """)

            elif choice_ability_invoker == 3:
                if cooldown == 1:
                    cooldown -= 1        
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")

            else:
                print("Такой способности не существует!")


def storyteller():
    print(
        """
Привет! Ты попал в увлекательное путешествие.
Тебе предстоит сразиться со врагами и выбрать путь,
по которому ты будешь идти
        """
    )

    choice = int(
        input(
            """
Введи сюда своё решение: 
1. Я согласен. Пойду дальше
2. Нет, спасибо, я лучше откажусь
                        
    Выбери 1 или 2:
    """
        )
    )
    if choice == 1:
        print(
            """
    История твоего персонажа была такой.       
                    """
        )
        if player.__class__.__name__ == "Axe":
            text_storyteller.past_story(2, 11)
        elif player.__class__.__name__ == "Invoker":
            text_storyteller.past_story(23, 34)
        elif player.__class__.__name__ == "Assasin":
            text_storyteller.past_story(13, 21)
        else:
            choice_character()
        choice = int(
            input(
                """
Начать приключение?

1.Да
2.Я хочу поменять персонажа.
              
Выбери 1 или 2:
"""
            )
        )
        if choice == 1:
            text_storyteller.past_story(38, 42)
            battle()
        elif choice == 2:
            choice_character()

    elif choice == 2:
        choice_exit = input("Вы уверены что хотите выйти?(Да / Нет):")

        if choice_exit.lower() == "да":
            print("Спасибо, что зашел. Удачи!")
            flag = False

        elif choice_exit.lower() == "нет":
            battle()

        else:
            print("Некорректный ввод")


def lobby():

    choice = int(
        input(
            """
Heroes and Magic
          
1.Начать игру
2.Уровень сложности

Выбери 1 или 2:
"""
        )
    )
    if choice == 1:
        return choice_character()

    elif choice == 2:
        choice2 = int(
            input(
                """
1.Низкий
2.Нормальный
3.Хардкор

Выбери 1 или 2 или 3:"""
            )
        )
        if choice2 == 1:
            difficult = 0.5
            return lobby()
        elif choice2 == 2:
            difficult = 1
            return lobby()
        elif choice2 == 3:
            difficult = 1.5
            return lobby()
        else:
            print("Некорректный ввод")
            return lobby()
    else:
        print("Некорректный ввод")
        return lobby()


if __name__ == "__main__":
    lobby()
