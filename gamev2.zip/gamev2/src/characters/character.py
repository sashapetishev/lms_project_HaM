class Character:
    def __init__(self, name, health_pull=100, damage=15, armor=5, mana=0):
        self.name = name
        self.health_pull = health_pull
        self.health = health_pull
        self.damage = damage
        self.armor = armor
        self.mana = mana  # Добавляем mana

    def getting_damage(self, enemy):
        self.health -= enemy.damage - 1 - self.armor / 100

    def use_heal_thing(self):
        self.health += 20
        print(
            f"""
Вы восстановили здоровье.
Ваш уровень здоровья: {self.health}
"""
        )
