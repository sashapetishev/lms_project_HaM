from .character import Character


class Invoker(Character):
    def __init__(self, name="default", health_pull=80, damage=14, armor=4):
        super().__init__(name, health_pull, damage, armor)

    def mages_attack(self, enemy):
        mages_attack = self.damage + 20
        print("Вы использовали способность 'Санстрайк'")
        enemy.health -= mages_attack

    def mirror_damage(self, enemy):
        enemy.health -= enemy.damage
        print(
            """
Вы использовали способность "Отражение урона"
Вы отразите одну атаку, урон получит враг, который атаковал вас.
        """
        )
