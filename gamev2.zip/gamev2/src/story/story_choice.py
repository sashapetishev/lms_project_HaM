from battles import battle3, battle2
import story.text_storyteller as text_storyteller


def story_choice(player, difficult):
    choice = int(input(text_storyteller.past_story(50, 55)))
    if choice == 1:
        pure_story_continue(player, difficult)
    elif choice == 2:
        shadow_story_continue(player, difficult)
    else:
        print("Некорректный ввод.")


def pure_story_continue(player, difficult):
    text_storyteller.past_story(57, 57)
    battle3(player, difficult)


def shadow_story_continue(player, difficult):
    text_storyteller.past_story(59, 60)
    battle2(player, difficult)
