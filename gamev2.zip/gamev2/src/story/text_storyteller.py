def get_string(line, file):

    with open(file, "r", encoding="utf-8") as f:
        file_lines = f.readlines()
        print(file_lines[line], end="")


def past_story(start_pos_line, end_pos_line):

    for now_line in range(start_pos_line, end_pos_line):
        get_string(now_line, "src/story/123.txt")
