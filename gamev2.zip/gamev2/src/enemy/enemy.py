class Enemy:
    def __init__(self, difficult, health_pull=100, damage=17, armor=3):
        self.armor = armor * difficult
        self.damage = damage * difficult
        self.health_pull = health_pull * difficult
        self.health = self.health_pull

    def getting_damage(self, player):
        self.health -= player.damage - 1 - self.armor / 100

    def use_heal_thing(self):
        self.health += 5
        if self.health > self.health_pull:
            self.health = self.health_pull


class Enemy2(Enemy):
    def __init__(self, difficult):
        super().__init__(difficult, health_pull=90, damage=19, armor=5)


class Enemy3(Enemy):
    def __init__(self, difficult):
        super().__init__(difficult, health_pull=100, damage=20, armor=8)
