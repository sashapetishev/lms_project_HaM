from enemy.enemy import Enemy2, Enemy3
from story import text_storyteller


def enemy_procast(player, enemy):
    """Обработка действий врага."""
    enemy.use_heal_thing()
    player.getting_damage(enemy)
    print(f"Противник нанес вам {enemy.damage}")


def battle2(player, difficult):
    if enemy.health <= 0:
        flag = False
        text_storyteller.past_story(62, 64)
    elif player.health <= 0:
        flag = False
        text_storyteller.past_story(66, 69)
    else:
        print(
            """
            
    Вы пришли в замок за артефактом, но встречаете Рыцарей света в большом количестве, пока основные силы сражаются друг с другом вы решаете напасть на их командующего.          
            
            """
        )
        enemy = Enemy2(difficult)
        flag = True
        cooldown = 0
        while flag:
            if player.__class__.__name__ == "Axe":
                print(
                    """
    Тебе доступны следующие способности:
    1. Усиление брони, твоя броня усилится в 1,5 раза.
    2. Нанести урон врагу.
                        """
                )
                choice_ability_paladin = int(input("Введите ваш выбор: "))
                if choice_ability_paladin == 1:
                    if cooldown % 2 == 0:
                        player.double_armor()
                        enemy_procast()
                        cooldown += 1
                        if enemy.health <= 0:
                            print(f"Здоровье противника: 0")
                        else:
                            print(f"Здоровье противника:{int(enemy.health)}")
                        if player.health <= 0:
                            print(f"Здоровье игрока: 0")
                        else:
                            print(f"Здоровье игрока:{int(player.health)}")
                    else:
                        print(
                            """
    Способность на перезарядке.                         
                            """
                        )

                elif choice_ability_paladin == 2:
                    if cooldown == 1:
                        cooldown -= 1
                        enemy.getting_damage()
                        enemy_procast()
                        if enemy.health <= 0:
                            print(f"Здоровье противника: 0")
                        else:
                            print(f"Здоровье противника:{int(enemy.health)}")
                        if player.health <= 0:
                            print(f"Здоровье игрока: 0")
                        else:
                            print(f"Здоровье игрока:{int(player.health)}")
                    else:
                        enemy.getting_damage()
                        enemy_procast()
                        if enemy.health <= 0:
                            print(f"Здоровье противника: 0")
                        else:
                            print(f"Здоровье противника:{int(enemy.health)}")
                        if player.health <= 0:
                            print(f"Здоровье игрока: 0")
                        else:
                            print(f"Здоровье игрока:{int(player.health)}")

            elif player.__class__.__name__ == "Assasin":
                print(
                    """
    Тебе доступны следующие способности:
    1. Двойной урон, твой урон увеличится в 2 раза
    2. Нанести урон врагу.
    Врожденная способность: Шанс уклонения 20% """
                )
                choice_ability_assasin = int(input("Введите ваш выбор: "))
                if choice_ability_assasin == 1:
                    if cooldown % 2 == 0:
                        player.double_damage()
                        player.passive_ability()
                        enemy_procast()
                        cooldown += 1
                        if enemy.health <= 0:
                            print(f"Здоровье противника: 0")
                        else:
                            print(f"Здоровье противника:{int(enemy.health)}")
                        if player.health <= 0:
                            print(f"Здоровье игрока: 0")
                        else:
                            print(f"Здоровье игрока:{int(player.health)}")
                    else:
                        print(
                            """
    Способность на перезарядке.                         
                            """
                        )

                elif choice_ability_assasin == 2:
                    if cooldown == 1:
                        cooldown -= 1
                        enemy.getting_damage()
                        enemy_procast()
                        if enemy.health <= 0:
                            print(f"Здоровье противника: 0")
                        else:
                            print(f"Здоровье противника:{int(enemy.health)}")
                        if player.health <= 0:
                            print(f"Здоровье игрока: 0")
                        else:
                            print(f"Здоровье игрока:{int(player.health)}")
                    else:
                        enemy.getting_damage()
                        enemy_procast()
                        if enemy.health <= 0:
                            print(f"Здоровье противника: 0")
                        else:
                            print(f"Здоровье противника:{int(enemy.health)}")
                        if player.health <= 0:
                            print(f"Здоровье игрока: 0")
                        else:
                            print(f"Здоровье игрока:{int(player.health)}")

            elif player.__class__.__name__ == "Invoker":
                print(
                    """
    Тебе доступны следующие способности:
    1. Санстрайк. Враг получит чистый урон,
    который не будет уменьшен из-за брони.
    Он равен обычному урону
    2. Отражение урона. Урон от атаки врага
    получит враг, который вас атаковал.
    3. Нанести урон врагу. """
                )
                choice_ability_invoker = int(input("Введите ваш выбор: "))

                if choice_ability_invoker == 1:
                    if cooldown % 2 == 0:
                        player.mages_attack()
                        enemy_procast()
                        cooldown += 1
                        if enemy.health <= 0:
                            print(f"Здоровье противника: 0")
                        else:
                            print(f"Здоровье противника:{enemy.health}")
                        if player.health <= 0:
                            print(f"Здоровье игрока: 0")
                        else:
                            print(f"Здоровье игрока:{player.health}")
                    else:
                        print(
                            """
    Способность на перезарядке.                         
                            """
                        )

                elif choice_ability_invoker == 2:
                    if cooldown % 2 == 0:
                        player.mirror_damage()
                        cooldown += 1
                        if enemy.health <= 0:
                            print(f"Здоровье противника: 0")
                        else:
                            print(f"Здоровье противника:{enemy.health}")
                        if player.health <= 0:
                            print(f"Здоровье игрока: 0")
                        else:
                            print(f"Здоровье игрока:{player.health}")
                    else:
                        print(
                            """
    Способность на перезарядке.                         
                            """
                        )

                elif choice_ability_invoker == 3:
                    if cooldown == 1:
                        cooldown -= 1
                        enemy.getting_damage()
                        enemy_procast()
                        if enemy.health <= 0:
                            print(f"Здоровье противника: 0")
                        else:
                            print(f"Здоровье противника:{enemy.health}")
                        if player.health <= 0:
                            print(f"Здоровье игрока: 0")
                        else:
                            print(f"Здоровье игрока:{player.health}")
                    else:
                        enemy.getting_damage()
                        enemy_procast()
                        if enemy.health <= 0:
                            print(f"Здоровье противника: 0")
                        else:
                            print(f"Здоровье противника:{enemy.health}")
                        if player.health <= 0:
                            print(f"Здоровье игрока: 0")
                        else:
                            print(f"Здоровье игрока:{player.health}")

                else:
                    print("Такой способности не существует!")


def battle3(player, difficult):
    print(
        """
          
Вы вместе с рыцарями пришли в замок за артефактом, вам преграждают путь войска Теневых братьев, вы решаете сразиться с превосходящим вас по силе паладином теней.
          
          """
    )
    enemy = Enemy3(difficult)
    flag = True
    cooldown = 0
    while flag:
        if player.__class__.__name__ == "Axe":
            print(
                """
Тебе доступны следующие способности:
1. Усиление брони, твоя броня усилится в 1,5 раза.
2. Нанести урон врагу.
                    """
            )
            choice_ability_paladin = int(input("Введите ваш выбор: "))
            if choice_ability_paladin == 1:
                if cooldown % 2 == 0:
                    player.double_armor()
                    enemy_procast()
                    cooldown += 1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")
                else:
                    print(
                        """
Способность на перезарядке.                         
                          """
                    )

            elif choice_ability_paladin == 2:
                if cooldown == 1:
                    cooldown -= 1
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")
                else:
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")

        elif player.__class__.__name__ == "Assasin":
            print(
                """
Тебе доступны следующие способности:
1. Двойной урон, твой урон увеличится в 2 раза
2. Нанести урон врагу.
Врожденная способность: Шанс уклонения 20% """
            )
            choice_ability_assasin = int(input("Введите ваш выбор: "))
            if choice_ability_assasin == 1:
                if cooldown % 2 == 0:
                    player.double_damage()
                    player.passive_ability()
                    enemy_procast()
                    cooldown += 1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")
                else:
                    print(
                        """
Способность на перезарядке.                         
                          """
                    )

            elif choice_ability_assasin == 2:
                if cooldown == 1:
                    cooldown -= 1
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")
                else:
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{int(enemy.health)}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{int(player.health)}")

        elif player.__class__.__name__ == "Invoker":
            print(
                """
Тебе доступны следующие способности:
1. Санстрайк. Враг получит чистый урон,
который не будет уменьшен из-за брони.
Он равен обычному урону
2. Отражение урона. Урон от атаки врага
получит враг, который вас атаковал.
3. Нанести урон врагу. """
            )
            choice_ability_invoker = int(input("Введите ваш выбор: "))

            if choice_ability_invoker == 1:
                if cooldown % 2 == 0:
                    player.mages_attack()
                    enemy_procast()
                    cooldown += 1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    print(
                        """
Способность на перезарядке.                         
                          """
                    )

            elif choice_ability_invoker == 2:
                if cooldown % 2 == 0:
                    player.mirror_damage()
                    cooldown += 1
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    print(
                        """
Способность на перезарядке.                         
                          """
                    )

            elif choice_ability_invoker == 3:
                if cooldown == 1:
                    cooldown -= 1
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")
                else:
                    enemy.getting_damage()
                    enemy_procast()
                    if enemy.health <= 0:
                        print(f"Здоровье противника: 0")
                    else:
                        print(f"Здоровье противника:{enemy.health}")
                    if player.health <= 0:
                        print(f"Здоровье игрока: 0")
                    else:
                        print(f"Здоровье игрока:{player.health}")

            else:
                print("Такой способности не существует!")
        elif enemy.health <= 0:
            flag = False
            text_storyteller.past_story(71, 74)
        elif player.health <= 0:
            flag = False
            text_storyteller.past_story(76, 78)
